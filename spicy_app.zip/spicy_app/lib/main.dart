import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:package_info_plus/package_info_plus.dart';

const kPkg = 'com.spicy.original';
const kPass = 'ly19';
const kRights = '© جميع الحقوق محفوظة لسبايسي الأصلي';
const kEmails = [
  'support@whatsapp.com',
  'smb@support.whatsapp.com',
  'android@support.whatsapp.com',
  'iphone@support.whatsapp.com',
  'web@support.whatsapp.com',
  'support@support.whatsapp.com',
  'android_web@support.whatsapp.com',
  'ios_web@support.whatsapp.com',
];

const strict = [
  {'t': 'طلب رسمي', 's': 'Request to review and restore my banned number {phone}',
   'b': 'Dear WhatsApp Support Team,\n\nMy WhatsApp number {phone} was banned. I use WhatsApp only for personal communication and I have not violated the Terms of Service. I believe this ban was applied by mistake.\n\nDevice: {device} (Android {android}). Account holder: {name}.\n\nI respectfully ask you to review my account and restore access.\n\nSincerely,\n{name}'},
  {'t': 'حظر بالخطأ', 's': 'My number {phone} was banned by mistake - please review',
   'b': 'Hello WhatsApp Team,\n\nI am writing about the permanent ban on {phone}. I did not engage in spam, abuse, or any prohibited activity. I rely on this number daily for family and work.\n\nI kindly request a manual review by a human agent and the restoration of my account.\n\nName: {name}\nDevice: {device} / Android {android}\n\nThank you for your time.'},
  {'t': 'طلب جاد', 's': 'Urgent: account {phone} banned without any violation',
   'b': 'To the WhatsApp Support Team,\n\nMy account {phone} was banned unexpectedly. I have always followed your policies, and I believe an automated system flagged it incorrectly.\n\nI request an urgent manual review. I am ready to provide any further information you need.\n\nRegards,\n{name}\n{device} - Android {android}'},
  {'t': 'محتاج الرقم', 's': 'Please reinstate WhatsApp number {phone}',
   'b': 'Dear Support,\n\nI am asking you to reconsider the ban on {phone}. This number is important for my daily communication, and I have not knowingly broken any rule.\n\nIf there was an error on my side, I apologize and will follow the guidelines strictly in the future. Please review the case and lift the restriction.\n\nThank you,\n{name}\nDevice: {device}, Android {android}'},
  {'t': 'استئناف نهائي', 's': 'Appeal against ban - {phone}',
   'b': 'Hello,\n\nThis is my appeal regarding the ban on {phone}. I have reviewed the Terms of Service and I did not violate them. I believe a system error caused the ban.\n\nPlease escalate this to your review team and restore my account as soon as possible.\n\nBest regards,\n{name}\n{device} / Android {android}'},
];

const review = [
  {'t': 'مراجعة 1', 's': 'Account {phone} stuck on "Request a review"',
   'b': 'Dear WhatsApp Support,\n\nMy number {phone} is stuck on the "Request a review" screen. I have not violated the Terms of Service and ask you to complete the review so I can access my account again.\n\nName: {name}\nDevice: {device} / Android {android}\n\nThank you.'},
  {'t': 'مراجعة 2', 's': 'Please complete the review of {phone}',
   'b': 'Hello Team,\n\nI submitted a review request for {phone} but the account is still restricted. Kindly process my request and restore access.\n\nSincerely,\n{name}\n{device} - Android {android}'},
  {'t': 'مراجعة 3', 's': 'Pending review for number {phone}',
   'b': 'To WhatsApp Support,\n\nThe review for my number {phone} is still pending. I use this number for personal communication only. Please finish the review as soon as possible.\n\nThank you,\n{name}\nDevice: {device}, Android {android}'},
];

const guessA = [
  {'t': 'دخول 1', 's': 'Login not available for {phone}',
   'b': 'Dear WhatsApp Support,\n\nWhen I try to register {phone}, I get "Login not available right now". I have not violated any policy. Please check my number and fix the issue.\n\nThank you.'},
  {'t': 'دخول 2', 's': 'Cannot log in with number {phone}',
   'b': 'Hello Team,\n\nI cannot log in to WhatsApp with {phone} because the app says login is not available. Please review the number and allow me to verify it.\n\nRegards.'},
  {'t': 'دخول 3', 's': 'Verification problem - {phone}',
   'b': 'To Support,\n\nMy number {phone} shows "Login not available". Please remove any restriction on the number and let me sign in normally.\n\nThanks.'},
];
const guessB = [
  {'t': 'محاولة 1', 's': 'Cannot receive code - try again in an hour - {phone}',
   'b': 'Dear WhatsApp Support,\n\nFor {phone} I always get "Try again in 1 hour" when I request the verification code. Please reset this limit so I can verify my number.\n\nThank you.'},
  {'t': 'محاولة 2', 's': 'Verification code blocked for {phone}',
   'b': 'Hello Team,\n\nI cannot request a code for {phone} because the app keeps asking me to try again later. Please check the number and lift the temporary limit.\n\nRegards.'},
  {'t': 'محاولة 3', 's': 'Please reset code limit - {phone}',
   'b': 'To Support,\n\nMy number {phone} is stuck on "Try again in 1 hour". I made no abuse of the service. Please reset the verification limit.\n\nThanks.'},
];

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final p = await PackageInfo.fromPlatform();
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Spicy',
    theme: ThemeData.dark(useMaterial3: true)
        .copyWith(colorScheme: const ColorScheme.dark(primary: Color(0xFFE53935))),
    builder: (c, w) => Directionality(textDirection: TextDirection.rtl, child: w!),
    home: p.packageName == kPkg ? const Gate() : const Stolen(),
  ));
}

Widget shell(String bg, String title, Widget body, {Widget? back}) => Scaffold(
      body: Stack(fit: StackFit.expand, children: [
        Image.asset('assets/$bg', fit: BoxFit.cover),
        Container(color: Colors.black54),
        SafeArea(
          child: Column(children: [
            Padding(
              padding: const EdgeInsets.all(8),
              child: Row(children: [
                if (back != null) back,
                Expanded(child: Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
              ]),
            ),
            Expanded(child: body),
            const Padding(padding: EdgeInsets.all(8), child: Text(kRights, style: TextStyle(color: Colors.white70, fontSize: 12))),
          ]),
        ),
      ]),
    );

Widget pic(String n, double s) => ClipRRect(
    borderRadius: BorderRadius.circular(16),
    child: Image.asset('assets/$n', width: s, height: s, fit: BoxFit.cover));

Widget btn(String t, VoidCallback f) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 6),
    child: SizedBox(
        width: double.infinity,
        height: 52,
        child: FilledButton(onPressed: f, child: Text(t, style: const TextStyle(fontSize: 16)))));

void go(BuildContext c, Widget w) => Navigator.push(c, MaterialPageRoute(builder: (_) => w));
Widget bk(BuildContext c) => IconButton(icon: const Icon(Icons.arrow_forward), onPressed: () => Navigator.pop(c));
Future<void> open(String u) => launchUrl(Uri.parse(u), mode: LaunchMode.externalApplication);

class Stolen extends StatelessWidget {
  const Stolen({super.key});
  @override
  Widget build(BuildContext c) => const Scaffold(
      body: Center(
          child: Padding(
              padding: EdgeInsets.all(24),
              child: Text('التطبيق ده اتسرق من سبايسي.\nانت بتستخدم نسخة معدلة.\nاطلب النسخة الأصلية من سبايسي: t.me/lokajusthere',
                  textAlign: TextAlign.center, style: TextStyle(fontSize: 20, color: Colors.redAccent)))));
}

class Gate extends StatefulWidget {
  const Gate({super.key});
  @override
  State<Gate> createState() => _G();
}

class _G extends State<Gate> {
  final t = TextEditingController();
  @override
  Widget build(BuildContext c) => shell(
      'bg_password.png',
      '',
      Padding(
          padding: const EdgeInsets.all(24),
          child: Column(children: [
            const Spacer(flex: 3),
            TextField(
                controller: t,
                obscureText: true,
                textAlign: TextAlign.center,
                decoration: const InputDecoration(hintText: 'ادخل كلمة السر', filled: true)),
            btn('دخول', () {
              if (t.text.trim() == kPass) {
                Navigator.pushReplacement(c, MaterialPageRoute(builder: (_) => const Home()));
              } else {
                ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content: Text('كلمة السر غلط')));
              }
            }),
            const Spacer(),
          ])));
}

class Home extends StatelessWidget {
  const Home({super.key});
  @override
  Widget build(BuildContext c) => shell(
      'bg_home.png',
      'Spicy Original',
      ListView(padding: const EdgeInsets.all(20), children: [
        const SizedBox(height: 160),
        btn('فك حظر مشدد', () => go(c, const Items('فك حظر مشدد', strict, true))),
        btn('فك طلب مراجعة في 5 دقائق', () => go(c, const Items('فك طلب مراجعة', review, true))),
        btn('فك تخمين', () => go(c, const GuessMenu())),
        btn('فك عن طريق سبايسي', () => go(c, const ViaSpicy())),
        btn('قنوات وحسابات سبايسي', () => go(c, const Accounts())),
      ]));
}

class GuessMenu extends StatelessWidget {
  const GuessMenu({super.key});
  @override
  Widget build(BuildContext c) => shell(
      'bg_sections.png',
      'بتواجهك مشكلة إيه؟',
      ListView(padding: const EdgeInsets.all(20), children: [
        btn('تسجيل دخول غير متوفر', () => go(c, const Items('تسجيل دخول غير متوفر', guessA, false))),
        btn('حاول مجددا بعد ساعة', () => go(c, const Items('حاول مجددا بعد ساعة', guessB, false))),
      ]),
      back: bk(c));
}

class Items extends StatelessWidget {
  final String title;
  final List<Map<String, String>> list;
  final bool data;
  const Items(this.title, this.list, this.data, {super.key});
  @override
  Widget build(BuildContext c) => shell(
      'bg_sections.png',
      title,
      ListView(padding: const EdgeInsets.all(20), children: [
        for (var i = 0; i < list.length; i++)
          btn('بند ${i + 1} - ${list[i]['t']}', () => go(c, Flow(list[i], data))),
      ]),
      back: bk(c));
}

class Flow extends StatefulWidget {
  final Map<String, String> m;
  final bool data;
  const Flow(this.m, this.data, {super.key});
  @override
  State<Flow> createState() => _F();
}

class _F extends State<Flow> {
  int step = 0;
  final ph = TextEditingController(), nm = TextEditingController(), dv = TextEditingController(), an = TextEditingController();
  String? err;
  void next() {
    if (step == 0) {
      final v = ph.text.trim();
      if (!RegExp(r'^01[0125][0-9]{8}$').hasMatch(v)) {
        setState(() => err = 'ادخل رقم مصري صحيح زي 01012345678 (010 / 011 / 012 / 015 بس)');
        return;
      }
      setState(() {
        err = null;
        step = widget.data ? 1 : 2;
      });
    } else if (step == 1) {
      if (nm.text.trim().isEmpty || dv.text.trim().isEmpty || an.text.trim().isEmpty) {
        setState(() => err = 'املا كل الخانات');
        return;
      }
      setState(() {
        err = null;
        step = 2;
      });
    }
  }

  String fill(String s) => s
      .replaceAll('{phone}', '+20${ph.text.trim().substring(1)}')
      .replaceAll('{name}', nm.text.trim().isEmpty ? 'WhatsApp user' : nm.text.trim())
      .replaceAll('{device}', dv.text.trim().isEmpty ? 'Android phone' : dv.text.trim())
      .replaceAll('{android}', an.text.trim().isEmpty ? 'latest' : an.text.trim());

  void send() => open('mailto:${kEmails.join(",")}?subject=${Uri.encodeComponent(fill(widget.m['s']!))}&body=${Uri.encodeComponent(fill(widget.m['b']!))}');

  Widget f(TextEditingController c, String h, {bool num = false}) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: TextField(
          controller: c,
          keyboardType: num ? TextInputType.number : TextInputType.text,
          decoration: InputDecoration(hintText: h, filled: true)));

  @override
  Widget build(BuildContext c) => shell(
      'bg_sections.png',
      widget.m['t']!,
      ListView(padding: const EdgeInsets.all(20), children: [
        if (step == 0) ...[
          const Text('ادخل الرقم الي عايز تفكه:'),
          f(ph, '01012345678', num: true),
          btn('التالي', next),
        ],
        if (step == 1) ...[
          const Text('بياناتك:'),
          f(nm, 'الاسم'),
          f(dv, 'نوع الفون (مثال: Samsung A14)'),
          f(an, 'إصدار أندرويد (مثال: 13)', num: true),
          btn('التالي', next),
        ],
        if (step == 2) ...[
          Text('جاهز: الإيميل هيفتح فيه الرقم ${ph.text.trim()} وإيميلات الدعم والرسالة.'),
          btn('ارسل', send),
        ],
        if (err != null) Text(err!, style: const TextStyle(color: Colors.redAccent)),
      ]),
      back: bk(c));
}

class ViaSpicy extends StatelessWidget {
  const ViaSpicy({super.key});
  @override
  Widget build(BuildContext c) => shell(
      'bg_sections.png',
      'فك عن طريق سبايسي',
      ListView(padding: const EdgeInsets.all(20), children: [
        const Text('سبايسي هيبذل أقصى جهده عشان يفك رقمك بأعلى نسبة نجاح. عشان تتواصل مع سبايسي اضغط هنا 👇🏻', style: TextStyle(fontSize: 17)),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: btn('اضغط هنا', () => open('https://t.me/lokajusthere'))),
          const SizedBox(width: 12),
          pic('pic_jacket.jpg', 90),
        ]),
      ]),
      back: bk(c));
}

class Accounts extends StatelessWidget {
  const Accounts({super.key});
  Widget row(BuildContext c, String pc, String label, String val, String url) => Card(
      color: Colors.black54,
      child: Padding(
          padding: const EdgeInsets.all(10),
          child: Row(children: [
            pic(pc, 70),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
              Text(val),
              Row(children: [
                TextButton(
                    onPressed: () {
                      Clipboard.setData(ClipboardData(text: val));
                      ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content: Text('تم النسخ')));
                    },
                    child: const Text('نسخ')),
                TextButton(onPressed: () => open(url), child: const Text('فتح')),
              ]),
            ])),
          ])));

  @override
  Widget build(BuildContext c) => shell(
      'bg_sections.png',
      'قنوات وحسابات سبايسي',
      ListView(padding: const EdgeInsets.all(16), children: [
        row(c, 'pic_car.jpg', 'حساب التليجرام', '@lokajusthere', 'https://t.me/lokajusthere'),
        row(c, 'pic_black.jpg', 'قناة التليجرام الرسمية', 'https://t.me/lokatrust_1', 'https://t.me/lokatrust_1'),
        row(c, 'pic_cat.jpg', 'بوت الأرقام', '@RedXNumbersBot', 'https://t.me/RedXNumbersBot'),
        row(c, 'pic_black.jpg', 'صفحة التيك توك', '@spicy_el7araq', 'https://www.tiktok.com/@spicy_el7araq'),
        const SizedBox(height: 8),
        Center(child: pic('pic_snow.jpg', 160)),
      ]),
      back: bk(c));
}
